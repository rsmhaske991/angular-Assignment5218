import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nested-for',
  templateUrl: './nested-for.component.html',
  styleUrls: ['./nested-for.component.css']
})
export class NestedForComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  members=[
    { name:'Raj', email:'raj@gmail.com', phone:'2222222222', socialacc:['facebook','orkut'] },
    { name:'Kumar', email:'kumar@gmail.com', phone:'3333333333', socialacc:['fb','gmail'] },
    { name:'Kiran', email:'kiran@gmail.com', phone:'4444444444', socialacc:['insta','tweeter'] },
    { name:'Manoj', email:'manoj@gmail.com', phone:'5555555555', socialacc:['linked in','yt'] },
    { name:'Mayur', email:'mayur@gmail.com', phone:'6666666666', socialacc:['monster','timesjob'] },

  ];
}
