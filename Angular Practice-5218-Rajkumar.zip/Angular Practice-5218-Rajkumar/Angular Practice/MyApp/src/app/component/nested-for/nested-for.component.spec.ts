import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NestedForComponent } from './nested-for.component';

describe('NestedForComponent', () => {
  let component: NestedForComponent;
  let fixture: ComponentFixture<NestedForComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NestedForComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NestedForComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
