import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-comments',
  templateUrl: './comments.component.html',
  styleUrls: ['./comments.component.css']
})
export class CommentsComponent implements OnInit {
  private URL="https://jsonplaceholder.typicode.com/comments";
  constructor(private http:HttpClient) { }
  commentsData:any;
  ngOnInit(): void {
    this.http.get(this.URL)
    .subscribe(res=>this.commentsData=res)
  }

}
