import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
private URL="https://jsonplaceholder.typicode.com/users";
userData:any;
  constructor(private http:HttpClient) { }

  ngOnInit(): void {
    this.http.get(this.URL)
    .subscribe(res=>this.userData=res)
  }

}
