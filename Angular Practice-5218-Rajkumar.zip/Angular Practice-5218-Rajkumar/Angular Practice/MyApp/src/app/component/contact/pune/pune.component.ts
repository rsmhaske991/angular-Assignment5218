import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pune',
  templateUrl: './pune.component.html',
  styleUrls: ['./pune.component.css']
})
export class PuneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
