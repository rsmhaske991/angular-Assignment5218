import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-albums',
  templateUrl: './albums.component.html',
  styleUrls: ['./albums.component.css']
})
export class AlbumsComponent implements OnInit {
  private URL="https://jsonplaceholder.typicode.com/albums";
  constructor(private http:HttpClient) { }
  albumData:any;
  ngOnInit(): void {
    this.http.get(this.URL)
    .subscribe(res=>this.albumData=res)
  }

}
