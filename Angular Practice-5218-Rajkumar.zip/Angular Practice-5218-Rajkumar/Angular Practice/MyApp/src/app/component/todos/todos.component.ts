import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-todos',
  templateUrl: './todos.component.html',
  styleUrls: ['./todos.component.css']
})
export class TodosComponent implements OnInit {
private URL="https://jsonplaceholder.typicode.com/todos";
todoData:any;
  constructor(private http:HttpClient) { }

  ngOnInit(): void {
    this.http.get(this.URL)
    .subscribe(res=>this.todoData=res)
  }

}
