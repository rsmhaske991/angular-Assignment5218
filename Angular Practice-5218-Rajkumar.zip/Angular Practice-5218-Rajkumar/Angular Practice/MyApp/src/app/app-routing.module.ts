import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './component/about/about.component';
import { GalleryComponent } from './component/gallery/gallery.component';
import { HomeComponent } from './component/home/home.component';

import { ContactComponent } from './component/contact/contact.component';
import { MumbaiComponent } from './component/contact/mumbai/mumbai.component';
import { PuneComponent } from './component/contact/pune/pune.component';

import { IfConditionComponent } from './component/if-condition/if-condition.component';
import { SwitchCaseComponent } from './component/switch-case/switch-case.component';
import { NestedForComponent } from './component/nested-for/nested-for.component';

import { UsersComponent } from './component/users/users.component';
import { TodosComponent } from './component/todos/todos.component';
import { PhotosComponent } from './component/photos/photos.component';
import { CommentsComponent } from './component/comments/comments.component'; 
import { PostsComponent } from './component/posts/posts.component';
import { AlbumsComponent } from './component/albums/albums.component';

const routes: Routes = [
  {path:'home',component:HomeComponent},
  {path:'about',component:AboutComponent},
  {path:'gallery',component:GalleryComponent},
  {path:'contact', component:ContactComponent, children:[
    {path:'pune',component:PuneComponent},
    {path:'mumbai',component:MumbaiComponent}
  ]},
  {path:'ifCondition',component:IfConditionComponent},
  {path:'switchCase',component:SwitchCaseComponent},
  {path:'nestedFor',component:NestedForComponent},

  {path:'posts',component:PostsComponent},
  {path:'users',component:UsersComponent},
  {path:'albums',component:AlbumsComponent},
  {path:'comments',component:CommentsComponent},
  {path:'photos',component:PhotosComponent},
  {path:'todos',component:TodosComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
