import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HttpClient, HttpClientModule} from '@angular/common/http';
import { NgxUiLoaderComponent, NgxUiLoaderHttpModule, NgxUiLoaderModule } from 'ngx-ui-loader';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './component/home/home.component';
import { AboutComponent } from './component/about/about.component';
import { GalleryComponent } from './component/gallery/gallery.component';
import { ContactComponent } from './component/contact/contact.component';
import { PuneComponent } from './component/contact/pune/pune.component';
import { MumbaiComponent } from './component/contact/mumbai/mumbai.component';
import { IfConditionComponent } from './component/if-condition/if-condition.component';
import { SwitchCaseComponent } from './component/switch-case/switch-case.component';
import { NestedForComponent } from './component/nested-for/nested-for.component';
import { PostsComponent } from './component/posts/posts.component';
import { TodosComponent } from './component/todos/todos.component';
import { UsersComponent } from './component/users/users.component';
import { CommentsComponent } from './component/comments/comments.component';
import { AlbumsComponent } from './component/albums/albums.component';
import { PhotosComponent } from './component/photos/photos.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutComponent,
    GalleryComponent,
    ContactComponent,
    PuneComponent,
    MumbaiComponent,
    IfConditionComponent,
    SwitchCaseComponent,
    NestedForComponent,
    PostsComponent,
    TodosComponent,
    UsersComponent,
    CommentsComponent,
    AlbumsComponent,
    PhotosComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    NgxUiLoaderModule,
    NgxUiLoaderHttpModule.forRoot({showForeground:true})
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
